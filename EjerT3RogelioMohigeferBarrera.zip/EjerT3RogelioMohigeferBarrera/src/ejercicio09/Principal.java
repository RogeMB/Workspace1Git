package ejercicio09;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Este programa tendría otra serie de clases, pero por simplificar lo haremos solo con 3 clases.
		* Crear un programa que simule una máquina vendedora de tickets de metro. Tendremos que
		* crear la clase Ticket (Clase POJO), la clase Maquina (donde estarán todos los métodos con
		* funcionalidad) y la clase principal o de prueba. tendrá un menú donde se pueda:
		*	• Comprar uno o varios billetes.
		*	• Calcular el cambio a devolver.
		*	• Imprimir por pantalla el billete. Solo uno. Si se han comprado “x” debemos mostrar en el
		*	  ticket el mensaje “válido para x personas”.
		*	• Opciones de operario: el operario que lleva el mantenimiento de la máquina, debe tener
		*	  disponible un método que le ofrezca el saldo total de la recaudación de la máquina en
		*	  ese día (no es necesario usar fechas) y pueda poner a cero el contador de saldo total.
		* 
		* Dentro de la opción de operario, también debe contar con la posibilidad de cambiar el precio de los
		* billetes ya que estos suelen subir todos los años.
		* 
		* Las operaciones para el operario se harán solo si se introduce la contraseña adecuada antes de
		* cualquier otra cosa.
		* 
		* Estas últimas funcionalidades también se harán con métodos dentro de la clase Maquina.*/
		
		int opcion = 0, numTickets;
		
		switch (opcion) {
		case 0: /*salir*/
			break;
		case 1: /*comprar tickets*/
			System.out.println("");
			break;
		case 2: /*calcular cambio*/
			break;
		case 3: /*Imprimir billete*/
			break;
		case 4: /*operaciones del operario*/
			break; 
		}

	}

}
