package ejercicio04conInterfaz;

public interface ICaducable {
	public boolean calcularCaducado ();
}
