package ejercicio02Interface;

public interface IEstadisticas {
	
	double calcularMinimo ();
	double calcularMaximo ();
	double calcularSumatorio ();

}
