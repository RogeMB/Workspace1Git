package ejercicio01Interface;

public interface IImpuesto {
	
	double calculoIva (double precio, int iva);
	
	double calculoIrpf (double sueldo);

}
