/**
 * enumeration package with 5 motor options to be choose.
 */

package ejercicio03;

public enum TipoCombustible {
	Gasolina, Diésel, Eléctrico, Gas, Híbrido
}
